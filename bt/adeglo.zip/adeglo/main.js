
 var day = new Date();
 var time = document.getElementById('dig_time');
 var body = document.getElementById('body');
 var hello = document.getElementById('hello');
 
var timeDay = day.getHours();
 console.log(hello);
 
 function digitized() {

var mins = day.getMinutes();
var secs = day.getSeconds();

mins = Ticking(mins);
secs = Ticking(secs);





time = timeDay + ":" + mins + ":" + secs;


//set array for getting


var clock = setTimeout(digitized, 1000);}

function Ticking(ticVal) {
    if (ticVal < 10) {
        ticVal = "0" + ticVal;
    }
    return ticVal;
}

function timeHello(){
    
    txtName = document.getElementById("txtName");
    name = txtName.value;
    
    if(name === ""){
        name = "Stranger";
    }
    else{
        name;
    }
   
    

    if(timeDay >= 0 && timeDay < 12){
        
        console.log(timeDay);
        hello.innerHTML =  'Good Morning ' + name; 
        hello.setAttribute('class','morning');
        body.setAttribute('class','morning');
        
        hello.innerHTML +=  "<br/>  The Time is " + time ; 
    }
    else if(timeDay >= 12 && timeDay < 17){
        hello.innerHTML =  'Good Afternoon ' + name;
        hello.setAttribute('class','afternoon');
        body.setAttribute('class','afternoon');
         hello.innerHTML +=  "<br/> The Time is " + time ; 
     }
     else if(timeDay >= 17 && timeDay < 20){
        hello.innerHTML =  'Good Evening ' + name;
        hello.setAttribute('class','evening');
        body.setAttribute('class','evening');
         hello.innerHTML +=  "<br/> The Time is " + time ; 
     }
     else{
        hello.innerHTML =  'Good Night ' + name;
        hello.setAttribute('class','night');
        body.setAttribute('class','night');
         hello.innerHTML +=  "<br/> The Time is " + time ; 
     }

    }     
console.log(hello);